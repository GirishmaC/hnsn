import React from "react";
import technology from "./technology";

class techfields extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "LOREM",
      isWatched: false,
    };
  }

  toggleResponse = () => {
    this.setState((previousState) => ({
      isWatched: !previousState.isWatched,
    }));
  };

  render() {
    const { title, isWatched } = this.state;
    return (
      <>
        <technology title={title} />
        <p>
          Trending Technology : {" "}
          <strong>{isWatched ? "React" : "JS"}</strong>
        </p>
        <button onClick={this.toggleResponse}>Technology</button>
      </>
    );
  }
}

export default techfields;