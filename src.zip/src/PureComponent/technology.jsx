import React from "react";

class technology extends React.PureComponent {
  render() {
    return (
      <p>
            title: <strong>{this.props.title}</strong>
      </p>
    );
  }
}

export default technology;